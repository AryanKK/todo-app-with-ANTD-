const connectionString = 'mongodb+srv://<user>:<pswrd>@cluster0.2oel2pj.mongodb.net/?retryWrites=true&w=majority'
module.exports = connectionString
