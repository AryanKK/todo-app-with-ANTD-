const config = {
  apiUrl: 'http://localhost:3001/api/todos/',
}

export default config
